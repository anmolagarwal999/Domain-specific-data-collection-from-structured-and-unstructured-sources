export default function getName(name) {
  return name.title || name;
}
